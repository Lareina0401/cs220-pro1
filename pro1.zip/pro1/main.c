#include<stdio.h>
#include<string.h>
#include<stdlib.h>

#include"poker.h"
#define MAX_LINE 1024


int main(int argc,char *argv[])
{
	struct Player player1;
	struct Player player2;
	struct Player player3;
	struct Community comm;
	char strLine[MAX_LINE];
	char *p;
	int i=0,grad1=0,grad2=0,grad3=0;
	int *best1,*best2,*best3,*best12,*best23;
	
	FILE *fp;
	fp=fopen(argv[1],"r");//open example.txt
	if(fp==NULL)
	{
		printf("Open Failed!\n");
		return -1;
	}
	while(!feof(fp))
	{
		fgets(strLine,MAX_LINE,fp);
		//printf("%s\n",strLine );
		p=strLine;
		if(*p=='\n')
		{
			break;
		}
		player1.cards[0].values= *p;
		//printf("%c\n",player1.cards[0].values);
		p++;
		player1.cards[0].suits=*p;
		//printf("%c\n",player1.cards[0].suits);
		p+=2;
		player1.cards[1].values=*p;
		//printf("%c\n",player1.cards[1].values);
		p++;
		player1.cards[1].suits=*p;
		
		p+=2;
		player2.cards[0].values= *p;
		//printf("%c\n",player2.cards[1].values);
		p++;
		player2.cards[0].suits=*p;
		//printf("%c\n",player1.cards[1].suits);
		p+=2;
		player2.cards[1].values=*p;
		//printf("%c\n",player2.cards[2].values);
		p++;
		player2.cards[1].suits=*p;
		p+=2;
		player3.cards[0].values= *p;
		//printf("%c\n",player3.cards[1].values);
		p++;
		player3.cards[0].suits=*p;
		//printf("%c\n",player1.cards[1].suits);
		p+=2;
		player3.cards[1].values=*p;
		//printf("%c\n",player3.cards[2].values);
		p++;
		player3.cards[1].suits=*p;
		p+=2;
		//printf("%c\n",*p );
		comm.cards[0].values=*p;
		p++;
		comm.cards[0].suits=*p;
		p+=2;
		//printf("%c\n",comm.cards[0].suits);
		comm.cards[1].values=*p;
		p++;
		comm.cards[1].suits=*p;
		p+=2;
		//printf("%c\n",comm.cards[1].suits);
		comm.cards[2].values=*p;
		p++;
		comm.cards[2].suits=*p;
		p+=2;
		//printf("%c\n",comm.cards[2].suits);
		comm.cards[3].values=*p;
		p++;
		comm.cards[3].suits=*p;
		p+=2;
		
		//printf("%c\n",comm.cards[3].suits);
		
		comm.cards[4].values=*p;
		p++;
		comm.cards[4].suits=*p;

		//printf("%c\n",comm.cards[4].suits);

		best1=GetLevel(player1,comm);
		/*for (int i = 0; i < 6; ++i)
		{
			printf("best1=%d\n",best1[i]);
		}*/
		best2=GetLevel(player2,comm);


		/*for (int i = 0; i < 6; ++i)
		{
			printf("best2=%d\n",best2[i]);
		}*/

		best3=GetLevel(player3,comm);
		/*for (int i = 0; i < 6; ++i)
		{
			printf("best3=%d\n",best3[i]);
		}*/
		
		best12=Comp(best1,best2);
		if(best12==best1)
		{
			best23=Comp(best1,best3);
			if(best23==best3)
			{
				printf("Player 3 wins.\n");
			}
			else{
				printf("Player 1 wins.\n");
			}
		}
		else if(best12==best2)
		{
			best23=Comp(best2,best3);
			if(best23==best3)
			{
				printf("Player 3 wins.\n");
			}
			else{
				printf("Player 2 wins.\n");
			}
		}
		free(best1);
		free(best2);
		free(best3);
		//free(best12);
		//free(best23);

	}
	fclose(fp);
	return 0;


	
	//read example in program;

	
}