#ifndef __Poker_H__
#define __Poker_H__
#include<stdio.h>
#include<string.h>
#include<stdlib.h>


//enum Value{_2=2,_3,_4,_5,_6,_7,_8,_9,_10,J=11,Q=12,K=13,A=14};
//enum Value{T=10,J=11,Q=12,K=13,A=14};
//enum Suit{S,H,D,C};
struct Card{
	char suits;
	char values;

};

struct Player{
	struct Card cards[2];
};

struct Community{
	struct Card cards[5];
};

struct Hand{//nest hand cards
	struct Card cards[5];
};

int* GetLevel(struct Player player,struct Community comm);
void Sort(unsigned int *handvalues);
int *Getgrade(struct Hand *currhand,unsigned int *handvalues);
int *Comp(int *besthand,int *temhand);

#endif