#ifndef __Poker_H__
#define __Poker_H__
#include<stdio.h>
#include<string.h>
#include<stdlib.h>


//enum Value{_2=2,_3,_4,_5,_6,_7,_8,_9,_10,J=11,Q=12,K=13,A=14};
//enum Value{J=11,Q=12,K=13,A=14};
//enum Suit{S,H,D,C};
struct Card{
	char suits;
	char values;

};

struct Player{
	struct Card cards[2];
};

struct Community{
	struct Card cards[5];
};

struct Hand{//nest hand cards
	struct Card cards[5];
};

void* GetLevel(struct Player player,struct Community comm);
void Sort(struct Hand *currhand);


#endif