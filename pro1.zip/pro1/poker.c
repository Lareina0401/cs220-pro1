#include<stdio.h>
#include<string.h>
#include<stdlib.h>

#include"poker.h"
int com[21][5]={{0,1,2,3,4},{0,1,2,3,5},{0,1,2,3,6},{0,1,2,4,5},{0,1,2,4,6},{0,1,2,5,6},

                 {0,1,3,4,5},{0,1,3,4,6},{0,1,3,5,6},{0,1,4,5,6},{0,2,3,4,5},{0,2,3,4,6},

                 {0,2,3,5,6},{0,2,4,5,6},{0,3,4,5,6},{1,2,3,4,5},{1,2,3,4,6},{1,2,3,5,6},

                 {1,2,4,5,6},{1,3,4,5,6},{2,3,4,5,6}};

int* GetLevel(struct Player player,struct Community comm);
{
	int i=0,k,inx;
	int *besthand;
	int *temhand;
	struct Hand hands;
	struct Card allcard[7];
	struct Hand *currhand;
	besthand=(int *)malloc(6 * sizeof(int));
	temhand= (int *)malloc(6 * sizeof(int));
	for(k=0;k<6;k++)
	{
		besthand[k]=0;
		temhand[k]=0;
	}
	//printf("%c %c\n",player.cards[0].suits,player.cards[0].values);
	allcard[0].suits=player.cards[0].suits;
	allcard[0].values=player.cards[0].values;
	allcard[1].suits=player.cards[1].suits;
	allcard[1].values=player.cards[1].values;
	allcard[2].suits=comm.cards[0].suits;
	allcard[2].values=comm.cards[0].values;
	allcard[3].suits=comm.cards[1].suits;
	allcard[3].values=comm.cards[1].values;
	allcard[4].suits=comm.cards[2].suits;
	allcard[4].values=comm.cards[2].values;
	allcard[5].suits=comm.cards[3].suits;
	allcard[5].values=comm.cards[3].values;
	allcard[6].suits=comm.cards[4].suits;
	allcard[6].values=comm.cards[4].values;

	//printf("%c\n",allcard[5].suits);
	//printf("%c\n",allcard[5].values);
	for(k=0;k<21;k++)
	{
		hands.cards[0].suits=allcard[com[k][0]].suits;
		hands.cards[0].values=allcard[com[k][0]].values;
		hands.cards[1].suits=allcard[com[k][1]].suits;
		hands.cards[1].values=allcard[com[k][1]].values;
		hands.cards[2].suits=allcard[com[k][2]].suits;
		hands.cards[2].values=allcard[com[k][2]].values;
		hands.cards[3].suits=allcard[com[k][3]].suits;
		hands.cards[3].values=allcard[com[k][3]].values;
		hands.cards[4].suits=allcard[com[k][4]].suits;
		hands.cards[4].values=allcard[com[k][4]].values;

		for(inx=0;inx<6;inx++)
		{
			if(hands.cards[inx].values=="T")
			{
				hands.cards[inx].values=10;
			}
			if(hands.cards[inx].values=="J")
			{
				hands.cards[inx].values=11;
			}
			if(hands.cards[inx].values=="Q")
			{
				hands.cards[inx].values=12;
			}
			if(hands.cards[inx].values=="K")
			{
                hands.cards[inx].values=13;
			}
			if(hands.cards[inx].values=="A")
			{
				hands.cards[inx].values=14;
			}
		}

		currhand=hands;
		Sort(currhand);





	}


	void Sort(struct Hand *currhand)
	{
		
	}
	

	

	
	
        
}

