#include<stdio.h>
#include<string.h>
#include<stdlib.h>

#include"poker.h"
int com[21][5]={{0,1,2,3,4},{0,1,2,3,5},{0,1,2,3,6},{0,1,2,4,5},{0,1,2,4,6},{0,1,2,5,6},

                 {0,1,3,4,5},{0,1,3,4,6},{0,1,3,5,6},{0,1,4,5,6},{0,2,3,4,5},{0,2,3,4,6},

                 {0,2,3,5,6},{0,2,4,5,6},{0,3,4,5,6},{1,2,3,4,5},{1,2,3,4,6},{1,2,3,5,6},

                 {1,2,4,5,6},{1,3,4,5,6},{2,3,4,5,6}};

int* GetLevel(struct Player player,struct Community comm)
{
	int i=0,k,inx;
	int *besthand;
	int *temhand;
	struct Hand hands;
	struct Card allcard[7];
	struct Hand *currhand;
	unsigned int *handvalues;
	besthand=(int *)malloc(6 * sizeof(int));
	temhand= (int *)malloc(6 * sizeof(int));
	handvalues=(int *)malloc(5 * sizeof(int));
	for(k=0;k<6;k++)
	{
		besthand[k]=0;
		temhand[k]=0;
	}
	//printf("%c %c\n",player.cards[0].suits,player.cards[0].values);
	allcard[0].suits=player.cards[0].suits;
	allcard[0].values=player.cards[0].values;
	allcard[1].suits=player.cards[1].suits;
	allcard[1].values=player.cards[1].values;
	allcard[2].suits=comm.cards[0].suits;
	allcard[2].values=comm.cards[0].values;
	allcard[3].suits=comm.cards[1].suits;
	allcard[3].values=comm.cards[1].values;
	allcard[4].suits=comm.cards[2].suits;
	allcard[4].values=comm.cards[2].values;
	allcard[5].suits=comm.cards[3].suits;
	allcard[5].values=comm.cards[3].values;
	allcard[6].suits=comm.cards[4].suits;
	allcard[6].values=comm.cards[4].values;

	//printf("%c\n",allcard[5].suits);
	//printf("getin successful%c\n",allcard[5].values);
	for(k=0;k<21;k++)
	{
		hands.cards[0].suits=allcard[com[k][0]].suits;
		hands.cards[0].values=allcard[com[k][0]].values;
		hands.cards[1].suits=allcard[com[k][1]].suits;
		hands.cards[1].values=allcard[com[k][1]].values;
		hands.cards[2].suits=allcard[com[k][2]].suits;
		hands.cards[2].values=allcard[com[k][2]].values;
		hands.cards[3].suits=allcard[com[k][3]].suits;
		hands.cards[3].values=allcard[com[k][3]].values;
		hands.cards[4].suits=allcard[com[k][4]].suits;
		hands.cards[4].values=allcard[com[k][4]].values;

		for(inx=0;inx<5;inx++)
		{
			if(hands.cards[inx].values=='T')
			{
				handvalues[inx]=10;
			}
			else if(hands.cards[inx].values=='J')
			{
				handvalues[inx]=11;
			}
			else if(hands.cards[inx].values=='Q')
			{
				handvalues[inx]=12;
			}
			else if(hands.cards[inx].values=='K')
			{
                handvalues[inx]=13;
			}
			else if(hands.cards[inx].values=='A')
			{
				handvalues[inx]=14;
			}
			else if(hands.cards[inx].values=='9')
			{
				handvalues[inx]=9;
			}
			else if(hands.cards[inx].values=='8')
			{
				handvalues[inx]=8;
			}
			else if(hands.cards[inx].values=='7')
			{
				handvalues[inx]=7;
			}
			else if(hands.cards[inx].values=='6')
			{
				handvalues[inx]=6;
			}
			else if(hands.cards[inx].values=='5')
			{
				handvalues[inx]=5;
			}
			else if(hands.cards[inx].values=='4')
			{
				handvalues[inx]=4;
			}
			else if(hands.cards[inx].values=='3')
			{
				handvalues[inx]=3;
			}
			else if(hands.cards[inx].values=='2')
			{
				handvalues[inx]=2;
			}
			
		}
		/*for(inx=0;inx<5;inx++)
		{
			printf("%s\n",hands.cards[inx].values );
			//printf("%d\n",handvalues[inx] );
		}*/



		//printf("here!!!!!!!\n");

		currhand=&hands;
		Sort(handvalues);//small to large


		/*for(i=0;i<5;i++)
		{
			printf("2:%d\n", handvalues[i]);///////2!
		}*/

		temhand=Getgrade(currhand,handvalues);
		

		/*for(i=0;i<6;i++)
		{
			printf("besthand000=%d\n",besthand[i]);
		}*/
       //compare 
		besthand=Comp(besthand,temhand);

		/*for(i=0;i<6;i++)
		{
			printf("besthand=%d\n",besthand[i]);
		}*/
	

	}
	//free(temhand);
	//free(handvalues);
	return besthand;
}


	void Sort(unsigned int* handvalues)//bubble sort from large to small
	{
		int i,j,len=5,tem;

		/*for(i=0;i<5;i++)
		{
			printf("1:%d\n", handvalues[i]);
		}*/
		
		for(i=0;i<len-1;i++)
		{
			for(j=0;j<len-1-i;j++)
			{
				if((handvalues[j])<(handvalues[j+1]))
				{//swap
					tem=handvalues[j];
					handvalues[j]=handvalues[j+1];
					handvalues[j+1]=tem;
				}

			}
		}
		//printf("sort finished!!!!\n");
		/*for(i=0;i<5;i++)
		{
			printf("%d\n", handvalues[i]);
		}*/
		return;
		
	}

	int *Getgrade(struct Hand *currhand,unsigned int *handvalues)
	{
		int *handgrade=(int *)malloc(6 * sizeof(int));//record the kind and grade
        int i,k,samesuit=0,straight=0,p;
        int count1=1,count2=1,pair1=0,pair2=0,location1=0,location2=0;
        for(i=0;i<6;i++)
        {
        	handgrade[i]=0;
        }
        for(i=0;i<5;i++)
		{
			//printf("3:%d\n", handvalues[i]);///////2!
			//printf("3.1:%c\n",currhand->cards[i].suits);
		}

		for(i=0;i<4;i++)
		{
			if(currhand->cards[i].suits!=currhand->cards[i+1].suits)
			{
				samesuit++;
				//printf("samesuit=%d\n",samesuit );
			}
		}
		if(samesuit==0)//flush
		{
			for(i=1;i<5;i++)
			{
				if((handvalues[i-1] - handvalues[i])==1)
					straight++;

			}
			if(straight==4)//straight
			{
				if(handvalues[0]==14)//royal
				{
					handgrade[0]=9;
				}
				else{
					handgrade[0]=8;//straight flush
					handgrade[1]=handvalues[0];//largest number
				}
			}
			else{
				handgrade[0]=5;//single flush
				for (int j = 0; j < 5; ++j)
				{
					handgrade[j+1]=handvalues[j];
				}
                //special condition:A2345
				if((handvalues[4]==2)&&(handvalues[3]==3)&&(handvalues[2]==4)&&(handvalues[1]==5)&&(handvalues[0]==14))
				{
					handgrade[0]=8;//straight flush:A 2 3 4 5
					handgrade[1]=5;
					handgrade[2]=0;
					handgrade[3]=0;
					handgrade[4]=0;
					handgrade[5]=0;

				}

			}
		}

		else{//not flush
			for(i=1;i<5;i++)
			{
				if((handvalues[i-1] - handvalues[i])==1)
					straight++;

			}
			if(straight==4)//straight
			{
				handgrade[0]=4;//straight
				handgrade[1]=handvalues[0];//largest value

			}
			else{//not straight
				p=1;
				while(p<5)
				{
					if((handvalues[p]) == (handvalues[p-1]))
					{
						if(count1==1)//not find pair before
						{
							count1++;
							pair1=handvalues[p];
							location1=p-1;
						}
						else{
							if((handvalues[p])==pair1)
							{
								count1++;
							}
							else{
								if(count2==1)
								{
									location2=p-1;
								}
								count2++;
								pair2=handvalues[p];
							}
						}
					}
					p++;
				}

				if(count1==4)//four of a kind
				{
					handgrade[0]=7;
					if(location1==0)
					{
						handgrade[1]=handvalues[4];
					}
					else if(location1==1)
					{
						handgrade[1] = handvalues[0];
					}

				}
				else if(((count1==3) && (count2==2)) || ((count1==2) && (count2==3) ))//full house
				{
					handgrade[0]=6;
					if(count1==3)
					{
						handgrade[1]=pair1;
						handgrade[2]=pair2;
					}
					else if(count2==3)
					{
						handgrade[1]=pair2;
						handgrade[2]=pair1;
					}
				}
				else if((count1==3)&&(count2==1))//three of a kind
				{
					handgrade[0]=3;
					handgrade[1]=pair1;
					if(location1==0)
					{
						handgrade[2]=handvalues[3];
						handgrade[3]=handvalues[4];

					}
					else if(location1==1)
					{
						handgrade[2]=handvalues[0];
						handgrade[3]=handvalues[4];
					}
					else if(location1==2)
					{
						handgrade[2]=handvalues[0];
						handgrade[3]=handvalues[1];
					}
				}
				else if((count1==2) && (count2==2))//two pairs
				{
					handgrade[0]=2;
					handgrade[1]=pair1;//larger pair
					handgrade[2]=pair2;
					if(location1==0)
					{
						if(location2==2)
						{
							handgrade[3]=handvalues[4];
						}
						else if(location2==3)
						{
							handgrade[3]=handvalues[2];
						}
					}
					else if(location1==1)
					{
						handgrade[3]=handvalues[0];
					}

				}
				else if((count1==2) && (count2==1))//one pair
				{
					handgrade[0]=1;
					handgrade[1]=pair1;
					if(location1==0)
					{
						handgrade[2]=handvalues[2];
						handgrade[3]=handvalues[3];
						handgrade[4]=handvalues[4];

					}
					else if(location1==1)
					{
						handgrade[2]=handvalues[0];
						handgrade[3]=handvalues[3];
						handgrade[4]=handvalues[4];
					}
					else if(location1==2)
					{
						handgrade[2]=handvalues[0];
						handgrade[3]=handvalues[1];
						handgrade[4]=handvalues[4];
					}
					else if(location1==3)
					{
						handgrade[2]=handvalues[0];
						handgrade[3]=handvalues[1];
						handgrade[4]=handvalues[2];
					}
				}
				else {
					handgrade[0]=0;
					for(int g=0;g<5;g++)
					{
						handgrade[g+1]=handvalues[g];
					}
					//special

					if((handvalues[4]==2)&&(handvalues[3]==3)&&(handvalues[2]==4)&&(handvalues[1]==5)&&(handvalues[0]==14))
					{
						handgrade[0]=4;
						handgrade[1]=5;
						handgrade[2]=0;
						handgrade[3]=0;
						handgrade[4]=0;
						handgrade[5]=0;


					}

				}
				}

                


			}
			

			/*for (int i = 0; i < 6; ++i)
		{
			printf("handgrade=%d\n",handgrade[i]);
		}*/

			return handgrade;



		
	}
	

	int *Comp(int *besthand,int *temhand)
	{
		int k=0;
		while(k<6)
		{
			if(temhand[k]==besthand[k])
				k++;
			else if(temhand[k]>besthand[k])
				return temhand;
			else
				return besthand;
		}
		return besthand;


	}

	

	
	
        


